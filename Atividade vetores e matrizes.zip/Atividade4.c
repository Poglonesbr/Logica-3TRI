#include <stdio.h>
#include <stdlib.h>


int main(void) {
  char vetor[5]={'c','i','n','c','o'};

  for(int i=0; i<5; i++) {
    printf("%c",vetor[i]);
  }
  return 0;
}