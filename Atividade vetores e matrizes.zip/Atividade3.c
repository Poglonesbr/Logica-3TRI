#include <stdio.h>
#include <stdlib.h>


int main(void) {
  int par[10], impar[10], resultado[20];

  printf("Digite 10 valores para o primeiro vetor:\n");
  for(int i=0; i<10; i++) {
    scanf("%d", &par[i]);
    if (resultado[i]%2 == 0) {
      resultado[i] = par[i];
    }
    
  }

  printf("Digite 10 valores para o segundo vetor:\n");
  for(int i=0; i<10; i++) {
    scanf("%d", &impar[i]);
    if (resultado[i]%2 != 0){
      resultado[i] = impar[i];
    }
    
  }

  printf("O vetor final eh:\n");
  for(int i=0; i<20; i++) {
    printf("%d\n", resultado[i]);
  }

  return 0;
}