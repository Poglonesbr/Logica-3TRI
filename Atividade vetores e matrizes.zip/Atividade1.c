#include <stdio.h>
#include <stdlib.h>


int main(void) {
  int x = 0, num, vetor[16], i;

  for(int i = 0; i < 16; i++) {
    printf("Digite o %d valor: ", i+1);
    scanf("%d", &vetor[i]);
  }

  for( i = 0; i < 8; i++) {
    for(x = 8; x < 16; x++) {
      num = vetor[i];
      vetor[i] = vetor[x];
      vetor[x] = num;
    }
  }

  for(int i = 0; i < 16; i++) {
    printf("%d, ",vetor[i]);
  }
  return 0;
}