#include <stdio.h>
#include <stdlib.h>


int main(void) {
  int vetor[40], pares=0;

  for(int i=0; i<40; i++) {
    printf("Digite seis valores: ");
    scanf("%d",&vetor[i]);

    if(vetor[i] % 2 == 0) {
      pares++;
    }
  }

  printf("\nTemos %d de numeros pares", pares);
  return 0;
}