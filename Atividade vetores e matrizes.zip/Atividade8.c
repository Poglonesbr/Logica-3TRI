#include <stdio.h>
#include <stdlib.h>


int main(void) {
  int  maior, soma, matriz[5][5], i, n = 0, x = 0;

  for( i = 0; i < 5; i++) {
    for( n = 0; n < 5; n++) {
      printf("Digite um valor para a posicao %d %d: ", i, n);
      scanf("%d", &matriz[i][n]);
    }
  }

 for (int m = 0; m < 5; m++) {
    if (matriz[m][x] >= matriz[0][0] && matriz[m][x] >= matriz[1][1] && matriz[m][x] >= matriz[2][2] && matriz[m][x] >= matriz[3][3] && matriz[m][x] >= matriz[4][4]) {
    maior = matriz[m][x];
    }
    x++;
  }
  soma = matriz[0][4] + matriz[1][3] + matriz[2][2] + matriz[3][1] + matriz[4][0];
  for (int i=0; i<5; i++){
    for(int i1=0; i1<5; i1++){
      printf(" %d ", matriz[i][i1]);
    }
    printf("\n");
  }
  
  printf("O maior numero da diagonal primaria eh %d \nE a soma dos numeros da diagonal secundario eh %d", maior, soma);
  return 0;
}