#include <stdio.h>
#include <string.h>

int main(void) {
  char questoes[20][10], gabarito[10] = { 'a', 'b','c', 'd', 'a', 'b', 'c', 'd', 'a', 'b'};
  int i, nota = 0;
  for( i = 0; i < 20; i++){ 
    for( int x = 0; x < 10; x++) {
      printf("Digite a resposta da questão %d do aluno numero %d: ", x+1, i+1);
      scanf("%s", &questoes[i][x]);
      while(questoes[i][x] != 'a' && questoes[i][x] != 'b' && questoes[i][x] != 'c' && questoes[i][x] != 'd'){
        printf("Resposta inválida, digite novamente a, b, c ou d: ");
        scanf(" %s", &questoes[i][x]);
      }
    if(questoes[i][x] == gabarito[x]){
      nota++;
    }
    }
    printf("A nota do aluno %d foi: %d\n\n", i+1, nota);
  }
  
  return 0;
}
