#include <stdio.h>
#include <string.h>

int main(void) {
  int m[3][3], maior=0, linha=0, coluna=0;

  for(int i=0; i<3; i++) {
    for(int x=0; x<3; x++) {
      printf("Digite um valor para a posicao %d %d: ", i, x);
      scanf("%d",&m[i][x]);
      if(m[i][x] > maior) {
        maior = m[i][x];
        linha = i;
        coluna = x;
      }
    }
  }

  printf("\nO maior valor desta matriz eh: %d ", maior);
  printf("\n\nSua posicao eh: %d %d",linha,coluna);
  return 0;
}