#include <stdio.h>
#include <stdlib.h>


int main(void) {
  int  num = 0, matriz[4][4], i, n, x;

  for( i = 0; i < 4; i++) {
    for( n = 0; n < 4; n++) {
      printf("Digite um valor para a posicao %d %d: ", i, n);
      scanf("%d", &matriz[i][n]);
    }
  }

  for( i = 0; i < 4; i++) {
    for( x = 0; x < 4; x++) {
      num = matriz[0][x];
      matriz[0][x] = matriz[i][3];
      matriz[i][3] = num;
    }

    
  }

  for( i = 0; i < 4; i++){
    printf("\n");
    for(x = 0; x < 4; x++){
      printf("%d, ", matriz[i][x]);  
    }
  }
    
  
  return 0;
}