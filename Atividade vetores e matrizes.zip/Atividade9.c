#include <stdio.h>
#include <string.h>

int main(void) {

  int mat[6][6], mai10 = 0;

  for(int i = 0; i < 6; i++) {
    for(int x = 0; x < 6; x++) {
      scanf("%d", &mat[i][x]);

      if(mat[i][x] > 10) {
        mai10++;
      }
    }
  }

  printf("A matriz tem %d valores maiores que 10: ", mai10);
  return 0;
}