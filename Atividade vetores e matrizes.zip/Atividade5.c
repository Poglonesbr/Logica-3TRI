#include <stdio.h>
#include <string.h>

int main(void) {
  char nomes[5][50];
  int i;

  for( i = 0; i < 5; i++) {
    printf("Digite um nome: ");
    scanf(" %s", nomes[i]);
  }
  
  printf("Os nomes sao:\n");
  for( i = 0; i < 5; i++) {
    printf("%s\n", nomes[i]);
  }

  printf("Os nomes na ordem inversa sao:\n");
  for( i = 4; i >= 0; i--) {
    printf("%s\n", nomes[i]);
  }

  return 0;
}
